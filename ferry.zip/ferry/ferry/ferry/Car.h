#pragma once
#include "Vehicle.h"
class Car :
	public Vehicle
{
private:
	int seats = 0;

public:

	Car(int sts, int len, string regN) : seats{ sts }, Vehicle{ len, regN } {}
	~Car();

	int getSeats();
	void printInfo();
};

