#include "Digger.h"

//Digger::Digger(int tra, int shov, int len, string regN) : Vehicle(len, regN) {
//	tracks = tra;
//	shovel = shov;
// }

//Digger::Digger(int tra, int len, string regN) : Vehicle(len, regN) {
//	tracks = tra;
//	shovel = 10;
//}

Digger::~Digger() {}

int Digger::getTracks() {
	return tracks;
}

int Digger::getShovel() {
	return shovel;
}

void Digger::printInfo() {
	cout << "  Tracks: " << getTracks() << endl;
	cout << "  Shovel Size: " << getShovel() << endl;
	cout << "  Length: " << getLength() << endl;
	cout << "  Registration Nr: " << getRegNum() << endl;
}