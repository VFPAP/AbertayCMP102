#include "Lorry.h"

//Lorry::Lorry(int maxL, int len, string regN) : Vehicle(len, regN) {
//	maxLoad = maxL;
//}

Lorry::~Lorry() {}

int Lorry::getMaxLoad() {
	return maxLoad;
}

void Lorry::printInfo() {
	cout << "  Max Load: " << getMaxLoad() << endl;
	cout << "  Length: " << getLength() << endl;
	cout << "  Registration Nr: " << getRegNum() << endl;
}