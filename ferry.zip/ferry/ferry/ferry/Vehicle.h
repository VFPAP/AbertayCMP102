#pragma once
#include <iostream>
#include <string>

using namespace std;

class Vehicle
{
private:
	int length;
	string regNum;

public:

	Vehicle(int len, string regN) : length{ len }, regNum{ regN }{}
	~Vehicle();

	int getLength();
	string getRegNum();

	virtual void printInfo();
};

