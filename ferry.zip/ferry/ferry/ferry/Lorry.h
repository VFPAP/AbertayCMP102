#pragma once
#include "Vehicle.h"
class Lorry :
	public Vehicle
{
private:
	int maxLoad = 0;

public:
	Lorry(int maxL, int len, string regN) : maxLoad{ maxL }, Vehicle{ len, regN } {}
	~Lorry();

	int getMaxLoad();
	void printInfo();

};

