#include "ArtLorry.h"

//ArtLorry::ArtLorry(int cabL, int trailerL, int maxL, int len, string regN) : Lorry(maxL, len, regN) {
//	cabLen = cabL;
//	trailerLen = trailerL;
//}

ArtLorry::~ArtLorry() {}

int ArtLorry::getCabLen() {
	return cabLen;
}

int ArtLorry::getTrailerLen() {
	return trailerLen;
}

void ArtLorry::printInfo() {
	cout << "  Cab Length: " << getCabLen() << endl;
	cout << "  Trailer Length: " << getTrailerLen() << endl;
	cout << "  Max Load: " << getMaxLoad() << endl;
	cout << "  Length: " << getLength() << endl;
	cout << "  Registration Nr: " << getRegNum() << endl;
}