#include "Bus.h"

//Bus::Bus(int psv, int maxP, int len, string regN) : Vehicle(len, regN) {
//	PSV = psv;
//	maxPax = maxP;
//}

Bus::~Bus() {}

int Bus::getPSV() {
	return PSV;
}

int Bus::getMaxPax() {
	return maxPax;
}

void Bus::printInfo() {
	cout << "  PSV: " << getPSV() << endl;
	cout << "  Max Passengers: " << getMaxPax() << endl;
	cout << "  Length: " << getLength() << endl;
	cout << "  Registration Nr: " << getRegNum() << endl;
}