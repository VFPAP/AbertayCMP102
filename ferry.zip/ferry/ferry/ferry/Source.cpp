#include <iostream>
#include "Ferry.h"
#include "Car.h"
#include "Bus.h"
#include "ArtLorry.h"
#include "Digger.h"

using namespace std;

int main() {

	/*
	Car car1(5, 4, "56-LF-98"); //(seats, len, regN)
	Bus bus1(5322, 100, 12, "85-QE-30"); //(psv, maxP, len, regN)
	Lorry lorry1(10000, 20, "21-LV-68"); //(maxL, len, regN)
	ArtLorry artlorry1(2, 20, 20000, 25, "36-ZA-92"); //(cabL, trailerL, maxL, len, regN)
	Digger digger1(4, 8, 10, "48-VQ-30"); //(tracks, shovel, len, regN)
	Digger digger2(4, 12, "71-ZL-83"); //(tracks, len, regN)
	*/

	Ferry ferry(100);

	int menuChoice = 1;

	while (menuChoice != 0)
	{
		cout << endl << endl << "Welcome to the Ferry Boat!" << endl << endl;
		cout << "What do you want to do?" << endl;
		cout << "  1: Add a Vehicle" << endl;
		cout << "  2: Get Information about the Ferry" << endl;
		cout << "  3: Get Information about Vehicles on Board" << endl;
		cout << "  4: Remove All Vehicles" << endl;
		cout << "  0: Quit" << endl << endl;

		cin >> menuChoice;

		if (menuChoice == 1) ferry.addVehicle();

		else if (menuChoice == 2) {
			cout << endl << "Capacity: " << ferry.getCapacity() << endl;
			cout << "Free Space: " << ferry.getFreeSpace() << endl << endl;
		}

		else if (menuChoice == 3) ferry.getReport();

		else if (menuChoice == 4) ferry.removeAll();

		else if (menuChoice == 0) continue;

		else cout << "Invalid Option!" << endl;
	}
	return 0;
}