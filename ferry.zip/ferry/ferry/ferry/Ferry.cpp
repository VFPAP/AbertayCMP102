#include <iostream>
#include <iomanip>
#include "Ferry.h"

//Ferry::Ferry(int cap) {
//	capacity = cap;
//	freeSpace = capacity;
//}

Ferry::~Ferry() {}

int Ferry::getCapacity() {
	return capacity;
}

int Ferry::getFreeSpace() {
	return freeSpace;
}

void Ferry::addVehicle() {
	int menuChoice = 1;

	while (menuChoice != 0)
	{
		cout << endl << endl << "Which vehicle?" << endl;
		cout << "  1: Car" << endl;
		cout << "  2: Bus" << endl;
		cout << "  3: Lorry" << endl;
		cout << "  4: Articulated Lorry" << endl;
		cout << "  5: Digger" << endl;
		cout << "  0: Quit" << endl << endl;

		cin >> menuChoice;

		if (menuChoice == 1) {

			int seats, len;
			string reg;

			cout << "Enter:" << endl;
			cout << "  Nr Seats: ";
			cin >> seats;

			do
			{
				cout << "  Length: ";
				cin >> len;
			} while (len <= 0);

			cout << "  Registration Nr: ";
			cin >> reg;

			if (len > getFreeSpace()) {
				cout << "No enough space to add this Car!" << endl;
				continue;
			}
			onBoard.emplace_back(new Car(seats, len, reg));
			onBoardTypes.push_back("Car");

			decFreeSpace(len);
		}

		else if (menuChoice == 2) {

			int PSV, maxPAX, len;
			string reg;

			cout << "Enter:" << endl;
			cout << "  PSV: ";
			cin >> PSV;
			cout << "  Max Passengers: ";
			cin >> maxPAX;

			do
			{
				cout << "  Length: ";
				cin >> len;
			} while (len <= 0);

			cout << "  Registration Number: ";
			cin >> reg;

			if (len > getFreeSpace()) {
				cout << "No enough space to add this Bus!" << endl;
				continue;
			}

			onBoard.emplace_back(new Bus(PSV, maxPAX, len, reg));
			onBoardTypes.push_back("Bus");

			decFreeSpace(len);
		}

		else if (menuChoice == 3) {

			int maxLoad, len;
			string reg;

			cout << "Enter:" << endl;
			cout << "  Max Load: ";
			cin >> maxLoad;

			do
			{
				cout << "  Length: ";
				cin >> len;
			} while (len <= 0);

			cout << "  Registration Number: ";
			cin >> reg;

			if (len > getFreeSpace()) {
				cout << "No enough space to add this Lorry!" << endl;
				continue;
			}

			onBoard.emplace_back(new Lorry(maxLoad, len, reg));
			onBoardTypes.push_back("Lorry");

			decFreeSpace(len);
		}

		else if (menuChoice == 4) {

			int cabLen, trailerLen, maxLoad, len;
			string reg;

			cout << "Enter:" << endl;
			cout << "  Cab Length: ";
			cin >> cabLen;
			cout << "  Trailer Length: ";
			cin >> trailerLen;
			cout << "  Max Load: ";
			cin >> maxLoad;

			do
			{
				cout << "  Length: ";
				cin >> len;
			} while (len <= 0);

			cout << "  Registration Number: ";
			cin >> reg;

			if (len > getFreeSpace()) {
				cout << "No enough space to add this Articulated Lorry!" << endl;
				continue;
			}

			onBoard.emplace_back(new ArtLorry(cabLen, trailerLen, maxLoad, len, reg));
			onBoardTypes.push_back("ArtLorry");

			decFreeSpace(len);
		}

		else if (menuChoice == 5) {

			int tracks, shovel, len;
			string reg;

			cout << "Enter:" << endl;
			cout << "  Tracks: ";
			cin >> tracks;
			cout << "  Shovel Size: [Enter '0' for default value] ";
			cin >> shovel;

			do
			{
				cout << "  Length: ";
				cin >> len;
			} while (len <= 0);

			cout << "  Registration Number: ";
			cin >> reg;

			if (len > getFreeSpace()) {
				cout << "No enough space to add this Articulated Lorry!" << endl;
				continue;
			}

			if (shovel == 0) onBoard.emplace_back(new Digger(tracks, len, reg));
			else onBoard.emplace_back(new Digger(tracks, shovel, len, reg));

			onBoardTypes.push_back("Digger");

			decFreeSpace(len);
		}

		else if (menuChoice == 0) continue;

		else cout << "Invalid Option!" << endl;
	}
}

void Ferry::decFreeSpace(int len) {
	freeSpace -= len;
}

void Ferry::getReport() {

	cout << "Capacity: " << getCapacity() << endl;
	cout << "Free Space: " << getFreeSpace() << endl << endl;

	for (int i = 0; i < onBoardTypes.size(); i++) {

		if (onBoardTypes[i] == "Car") {
			cout << endl << "Car:" << endl;
			static_cast<Car*>(onBoard[i])->printInfo();
		}

		else if (onBoardTypes[i] == "Bus") {
			cout << endl << "Bus:" << endl;
			static_cast<Bus*>(onBoard[i])->printInfo();
		}

		else if (onBoardTypes[i] == "Lorry") {
			cout << endl << "Lorry:" << endl;
			static_cast<Lorry*>(onBoard[i])->printInfo();
		}

		else if (onBoardTypes[i] == "ArtLorry") {
			cout << endl << "Articulated Lorry:" << endl;
			static_cast<ArtLorry*>(onBoard[i])->printInfo();
		}

		else if (onBoardTypes[i] == "Digger") {
			cout << endl << "Digger:" << endl;
			static_cast<Digger*>(onBoard[i])->printInfo();
		}

		else cout << endl << "Error!" << endl;
	}
}

void Ferry::removeAll() {
	for (int i = 0; i < onBoard.size(); i++) {
		delete onBoard[i];
	}
	onBoard.clear();

	freeSpace = capacity;
}