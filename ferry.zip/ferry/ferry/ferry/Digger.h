#pragma once
#include "Vehicle.h"
class Digger :
	public Vehicle
{
private:
	int tracks = 0;
	int shovel = 0;

public:
	Digger(int tra, int shov, int len, string regN) : tracks{ tra }, shovel{ shov }, Vehicle{ len, regN } {}
	Digger(int tra, int len, string regN) : tracks{ tra }, shovel{ 10 }, Vehicle{ len, regN } {}
	~Digger();

	int getTracks();
	int getShovel();
	void printInfo();

};
