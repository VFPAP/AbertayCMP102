#pragma once
#include "Lorry.h"
class ArtLorry :
	public Lorry
{
private:
	int cabLen = 0;
	int trailerLen = 0;

public:

	ArtLorry(int cabL, int traL, int maxL, int len, string regN) : cabLen{ cabL }, trailerLen{ traL }, Lorry{ maxL, len, regN } {}
	~ArtLorry();

	int getCabLen();
	int getTrailerLen();
	void printInfo();

};

