#pragma once
#include <vector>
#include "Vehicle.h"
#include "Car.h"
#include "Bus.h"
#include "ArtLorry.h"
#include "Digger.h"

class Ferry
{
private:
	int capacity = 0;
	int freeSpace = 0;

	vector<Vehicle*> onBoard;

	vector<string> onBoardTypes;

	void decFreeSpace(int);

public:

	Ferry(int cap) : capacity{ cap } {
		freeSpace = capacity;
	}

	~Ferry();

	int getCapacity();
	int getFreeSpace();
	void addVehicle();
	void getReport();
	void removeAll();

};

