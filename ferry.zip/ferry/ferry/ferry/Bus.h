#pragma once
#include "Vehicle.h"
class Bus :
	public Vehicle
{
private:
	int PSV = 0;
	int maxPax = 0;

public:
	Bus(int psv, int maxP, int len, string regN) : PSV{ psv }, maxPax{ maxP }, Vehicle{ len, regN } {}
	~Bus();

	int getPSV();
	int getMaxPax();
	void printInfo();

};

