#include "Car.h"

//Car::Car(int sts, int len, string regN) : Vehicle(len, regN) {
//	seats = sts;
//}

Car::~Car() {}

int Car::getSeats() {
	return seats;
}

void Car::printInfo() {
	cout << "  Seats: " << getSeats() << endl;
	cout << "  Length: " << getLength() << endl;
	cout << "  Registration Nr: " << getRegNum() << endl;
}