#include "Vehicle.h"

//Vehicle::Vehicle(int len, string regN) {
//	length = len;
//	regNum = regN;
//}

Vehicle::~Vehicle() {}

int Vehicle::getLength() {
	return length;
}

string Vehicle::getRegNum() {
	return regNum;
}

void Vehicle::printInfo() {}
