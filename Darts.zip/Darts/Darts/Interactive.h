#pragma once

#include "Game.h"
#include <thread> // To wait between rounds
#include <chrono> // To wait between rounds

class Interactive : public Game {
private:
	Player* bot;				// pointer to Player object
	string humName = "";		// name of human player
	int humRate = 80;			// human rate. CHANGE THIS TO CHANGE DIFFICULTY
	int humScore = 0;			// human score
	int game = 501;				// game type (301, 501, etc)
	bool hints = false;			// enable hints during game
	vector<string> validDarts;	// to store all possible valid darts

public:
	Interactive(Player*, string);	// constructor
	~Interactive();					// destructor

	void setHumRate(int);			// setter for human accuracy rate
	void populateValidDarts();		// adds each possible dart to vector<string> validDarts
	bool validDartChoice(string);	// checks if user's chosen dart is a valid dart. returns true if it is
	void enableHints();				// asks if user wants hints and returns true if affirmative
	void showHint(int);				// show hint depending on the roundScore
	int throwBull();				// throw for bull
	int throwSingle(int);			// throw for single
	int throwDouble(int);			// throw for double
	int throwTreble(int);			// throw for bull terble
	void playIntMatch();			// play interactive match (best of 13 sets)
	string playIntSet(char&);		// play interactive set (best of 5 games)
	string playIntGame(char);		// play interactive game (3 rounds each player)
	void humanPlay();				// play round with human
	void botPlay();					// play round with bot
	void printRoundTable(string, bool, string, bool, string, bool); // fancy table to be printed between darts to show stats of the human's round
};
