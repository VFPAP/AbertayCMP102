#include "Player.h"

Player::Player(string n, int rate) {
	name = n;
	successRate = rate;
}

Player::~Player() {}

string Player::getName() {
	return name;
}

int Player::getSuccessRate() {
	return successRate;
}

void Player::setSuccessRate(int rate) {
	successRate = rate;
}

int Player::getScore() {
	return score;
}

void Player::setScore(int s) {
	score = s;
}

void Player::incRoundsPlayed() {
	roundsPlayed++;
}

int Player::getRoundsPlayed() {
	return roundsPlayed;
}

void Player::incDartsThrown() {
	dartsThrown++;
}

int Player::getDartsThrown() {
	return dartsThrown;
}

void Player::estSuccessRate() {//in %
	estSuccRate = (double)targetHit / dartsThrown * 100;
}

double Player::getEstSuccessRate() {
	return estSuccRate;
}

void Player::incTargetHit() {
	targetHit++;
}

int Player::getWins() {
	return wins;
}

void Player::incWins() {
	wins++;
}