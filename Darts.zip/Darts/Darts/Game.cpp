#include "Game.h"
#include "Interactive.h" 
// I needed to include "Interactive.h" here and not in the "Game.h" because otherwise the compiler
//  would complain about the "base class Game not being defined"
// I searched the error online and I think it has something to do with the fact that "Game.h" includes
//  "Interactive.h" and "Interactive.h" includes "Game.h"...

Game::Game() {} // default constructor needed for the derived class Interactive

Game::Game(Player* x, Player* y) {

	// add both players' pointers to the player vector
	player.push_back(x);
	player.push_back(y);

	populateStrategy(); // adds the strategy for each possible score to the strategy map
}

Game::~Game() {} // destructor

string Game::getWinner() {
	return winner;
}

void Game::setWinner(string w) {
	winner = w;
}

void Game::resetPlayersScores() {
	// resets each player score depending on which game they are playing (301, 501, etc)
	for (unsigned int i = 0; i < player.size(); i++) {
		player[i]->setScore(game);
	}
}

void Game::playSingle() { // play single game

	resetPlayersScores();

	do {
		playRound(); // play round until one of the player's score is 0, i.e. the winner is decided

	} while (player[0]->getScore() != 0 && player[1]->getScore() != 0);
}

void Game::playFinal() {

	string results = "";

	do {
		cout << endl << "How many World Championships are we playing? ";
		cin >> champs;

		// prevents bad input to mess with cin
		if (cin.fail()) {
			cin.clear();
			cin.ignore(numeric_limits<streamsize>::max(), '\n');
		}

	} while (champs < 1); // at least 1 world championship

	cout << endl;

	// for every player that exists, ask the success rate and update it
	for (unsigned int i = 0; i < player.size(); i++) {
		int rate = 0;

		do {
			cout << "What is " << player[i]->getName() << "'s Success Rate? ";
			cin >> rate;

			// prevents bad input to mess with cin
			if (cin.fail()) {
				cin.clear();
				cin.ignore(numeric_limits<streamsize>::max(), '\n');
				rate = -1;
			}

		} while (rate < 0 || rate > 99);

		player[i]->setSuccessRate(rate);
	}

	for (int i = 0; i < champs; i++) {

		results = playMatch(); // play a match (best of 13 sets)

		// add result to frequency map to be used when printing the frequencies
		if (frequency.find(results) == frequency.end()) {
			// not found
			frequency.emplace(results, 1);
		}
		else {
			// found
			frequency[results]++;
		}
	}
}

string Game::playMatch() {

	if (champs == 1) {
		// To answer the question in Task 1: "if Sid threw first in game one, by what score in sets would he expect to win?"
		//   I've decided that every time we are playing only 1 Championship (champs == 1), Sid is throwing first in game
		//   one to see by what score he wins.

		if (player[0]->getName() != "Sid") {
			// Swap players in the vector:
			// Eg: {Joe, Sid} => {Sid, Joe}
			player.insert(player.begin(), player[1]);
			player.pop_back();
		}
	}
	// If champs != 1, at the start of each match each player plays "nearest the bull" to see who plays first - see Assessment Brief 4.1
	// Let's see who goes first
	else if ((rand() % 100) < 50) { // Joe is first

		if (player[0]->getName() != "Joe") { // joe is not the first in the vector, change that
			// Swap players in the vector:
			// Eg: {Sid, Joe} => {Joe, Sid}
			player.insert(player.begin(), player[1]);
			player.pop_back();
		}
	}
	else { //Sid is first
		if (player[0]->getName() != "Sid") {
			// Swap players in the vector:
			// Eg: {Joe, Sid} => {Sid, Joe}
			player.insert(player.begin(), player[1]);
			player.pop_back();
		}
	}

	int joeWinSet = 0; // to store joe's wins
	int sidWinSet = 0; //    "     sid's wins

	string result = ""; // to store the result

	do {

		result = playSet(); // play set (best of 5 games)

		// increment the wins variable of the winner
		if (result == "Joe") joeWinSet++;
		else if (result == "Sid") sidWinSet++;
		else cout << "Err";

	} while (joeWinSet != 7 && sidWinSet != 7);

	return (" " + to_string(joeWinSet) + "  :  " + to_string(sidWinSet)); // eg: " 7  :  4"
}

string Game::playSet() {

	int joeWinGame = 0; // to store joe's wins
	int sidWinGame = 0; // to store sid's wins

	string result = ""; // to store the result

	do {
		result = playGame(); // play game

		// increment the wins variable of the winner
		if (result == "Joe") joeWinGame++;
		else if (result == "Sid") sidWinGame++;
		else cout << "Err";

		// Like in tennis, after each game, players alternate in throwing first
		// Swap players in the vector:
		// Eg: {Joe, Sid} => {Sid, Joe}
		player.insert(player.begin(), player[1]);
		player.pop_back();

	} while (joeWinGame != 3 && sidWinGame != 3);

	// return the winner name
	if (joeWinGame > sidWinGame) return "Joe";
	else if (sidWinGame > joeWinGame) return "Sid";
	else {
		cout << "Err"; // debug purposes
		return "";
	}
}

string Game::playGame() {

	setWinner(""); // reset winner to play another single game

	playSingle(); // play one 501 game

	// search for the winner and increments its wins
	for (unsigned int i = 0; i < player.size(); i++) {
		if (getWinner() == player[i]->getName()) {
			player[i]->incWins();
		}
	}

	return getWinner();
}

void Game::playMulti() { // play multiple 501 games 

	int nrGames = 0; // how many games will be played

	do {
		cout << endl << "How many games are we playing? ";
		cin >> nrGames;

		// prevents bad input to mess with cin
		if (cin.fail()) {
			cin.clear();
			cin.ignore(numeric_limits<streamsize>::max(), '\n');
		}

	} while (nrGames < 2); // only accepts at least 2 games otherwise is 'single game mode'

	cout << endl;

	// for every player that exists, ask the success rate and update it
	for (unsigned int i = 0; i < player.size(); i++) {
		int rate = 0;

		do {
			cout << "What is " << player[i]->getName() << "'s Success Rate? ";
			cin >> rate;

			// prevents bad input to mess with cin
			if (cin.fail()) {
				cin.clear();
				cin.ignore(numeric_limits<streamsize>::max(), '\n');
				rate = -1;

			}

		} while (rate < 0 || rate > 99);

		player[i]->setSuccessRate(rate);
	}

	int first = 0;
	cout << endl << "Who's going first:" << endl << endl;

	for (unsigned int i = 0; i < player.size(); i++) {
		cout << "  " << i + 1 << ": " << player[i]->getName() << endl;
	}

	do {
		cout << endl << "Option> ";
		cin >> first;

		// prevents bad input to mess with cin
		if (cin.fail()) {
			cin.clear();
			cin.ignore(numeric_limits<streamsize>::max(), '\n');
		}

	} while (first != 1 && first != 2);

	if (first == 2) { // if sid's first, swap vector because by default joe's first
		// Swap players in the vector:
		// Eg: {Joe, Sid} => {Sid, Joe}
		player.insert(player.begin(), player[1]);
		player.pop_back();
	}

	for (int i = 0; i < nrGames; i++) {

		playSingle();// play one 501 game

		// search for the winner and increments its wins
		for (unsigned int i = 0; i < player.size(); i++) {
			if (getWinner() == player[i]->getName()) {
				player[i]->incWins();
			}
		}

		setWinner(""); // reset winner to play another single game
	}
}

void Game::playRound() {

	for (unsigned int i = 0; i < player.size(); i++) {

		if (getWinner() != "") { // If there's already a winner, we don't want to continue playing.	
			break;
		}

		player[i]->incRoundsPlayed(); // increment nr of player's rounds played

		int roundScore = playStrategy(player[i]); // play 1 round with the Enhanced Strategy

		player[i]->setScore(player[i]->getScore() - roundScore); // update player's score 

		// if the current player won the game with this round, we dont want the other player to continue playing
		if (player[i]->getScore() == 0) {
			setWinner(player[i]->getName());
			break;
		}
	}

	/*
	##
	# Old code for task 1 (without Enhanced Strategy)
	# There's an error because i'm throwing at bullseye to bring down the score rapidly instead of T20
	##


	for (int j = 0; j < 3; j++) { // 3 darts

		player[i]->incDartsThrown();

		int currentScore = player[i]->getScore();
		int roundScore = 0; // keeps track of the score of this round

		if (currentScore == 50) { // if player has only 50 points, he wants to throw to bullseye to end game
			roundScore = throwBull(player[i]);

			// if bullseye wasnt hit then nothing happens cause player needs to end the game with bullseye
			if (roundScore != 50) roundScore = 0;
		}

		else  { //(score > 50)
			// how far is the score from 50? cause we want to have 50 so then in the next round we can hit bullseye
		if (currentScore - 50 >= 50) { // eg: score=100 => score-50 <=> 100-50 = 50 => player wants to throw bullseye
				roundScore = throwBull(player[i]);
			}

		// score - 50 < 50   eg: score=80 => score-50 <=> 80-50 = 30 => player wants to throw to the maximum of singles, ie 20
		else  {
			if (currentScore - 50 > 20)
			{
				roundScore = throwSingle(20);
			}

			//score - 50 <= 20  eg: score=55 => score-50 <=> 55-50 = 5 => player wants to throw 5 to have 50 points in the round
			else  {
				roundScore = throwSingle(currentScore - 50);
			}
		}

		player[i]->estSuccessRate(); //after each round, calc the new estimated success rate

		// if player zeroed out the score then the roundScore is valid (and he wins the game)
		// OR if score - roundScore is >= 50, i.e. is valid, deduct roundScore from score
		if (currentScore - roundScore == 0) {
			if (currentScore % 2 == 0 || currentScore == 50) { // if the score 0 was preceded by an even score or 50, it's valid
				player[i]->setScore(currentScore - roundScore);
			}
		}

		// score must be > 1, otherwise player busts
		else if (currentScore - roundScore > 1) player[i]->setScore(currentScore - roundScore);

		// score - roundScore <= 1   break out of the "for loop" of the 3 darts because this round is ignored because player busted
		else break;

		// if the current player won the game with this round, we dont want the other player to continue playing
		if (currentScore == 0) {
			winner = player[i]->getName();
			break;
		}
	}*/
}

void Game::printResults(int mode) {

	system("cls");

	if (mode == 4) return; // if it's interactive mode, don't show anything cause results were already shown

	cout << endl << "Results: ";

	if (mode == 1) { // if Single 501 Game mode was selected

		cout << endl << endl << "|  Name  |" << setw(23) << "  Fixed Success Rate  |" << setw(27) << "  Estimated Success Rate  |";
		cout << setw(18) << "  Rounds Played  |" << setw(17) << "  Darts Thrown  |" << endl;

		cout << setfill('-') << setw(95) << '-' << endl;
		cout << setfill(' ');

		for (unsigned int i = 0; i < player.size(); i++) {
			cout << "|  " << setw(3) << player[i]->getName() << "   |  " << setw(10) << player[i]->getSuccessRate() << "          |  ";
			cout << setw(13) << fixed << setprecision(2) << player[i]->getEstSuccessRate() << "           |  " << setw(7);
			cout << player[i]->getRoundsPlayed() << "        |  " << setw(7) << player[i]->getDartsThrown() << "       |" << endl;
		}
		cout << setfill('-') << setw(95) << '-' << endl << endl;

		cout << endl << getWinner() << " won the game!" << endl << endl;
	}

	else if (mode == 2) { // if Multiple 501 Games mode was selected
		cout << "(For " << (player[0]->getWins() + player[1]->getWins()) << " games)" << endl << endl;

		cout << endl << "|  Name  |" << setw(23) << "  Fixed Success Rate  |" << setw(27) << "  Estimated Success Rate  |";
		cout << setw(18) << "  Rounds Played  |" << setw(17) << "  Darts Thrown  |" << setw(10) << "  Games Won  |" << endl;

		cout << setfill('-') << setw(109) << '-' << endl;
		cout << setfill(' ');

		for (unsigned int i = 0; i < player.size(); i++) {
			cout << "|  " << setw(3) << player[i]->getName() << "   |  " << setw(10) << player[i]->getSuccessRate() << "          |  ";
			cout << setw(13) << fixed << setprecision(2) << player[i]->getEstSuccessRate() << "           |  " << setw(9);
			cout << player[i]->getRoundsPlayed() << "      |  " << setw(9) << player[i]->getDartsThrown() << "     |" << setw(8);
			cout << player[i]->getWins() << "     |" << endl;
		}
		cout << setfill('-') << setw(109) << '-' << endl << endl;
	}

	else if (mode == 3) { // if World Championships mode was selected

		cout << "(For " << champs << " World Championships - Best of 13 sets, each set being the best of 5 games)" << endl << endl;

		cout << endl << "|  Name  |" << setw(23) << "  Fixed Success Rate  |" << setw(27) << "  Estimated Success Rate  |";
		cout << setw(18) << "  Rounds Played  |" << setw(17) << "  Darts Thrown  |" << setw(10) << "  Games Won  |" << endl;

		cout << setfill('-') << setw(109) << '-' << endl;
		cout << setfill(' ');

		for (unsigned int i = 0; i < player.size(); i++) {
			cout << "|  " << setw(3) << player[i]->getName() << "   |  " << setw(10) << player[i]->getSuccessRate() << "          |  ";
			cout << setw(13) << fixed << setprecision(2) << player[i]->getEstSuccessRate() << "           |  " << setw(9);
			cout << player[i]->getRoundsPlayed() << "      |  " << setw(9) << player[i]->getDartsThrown() << "     |" << setw(8);
			cout << player[i]->getWins() << "     |" << endl;
		}
		cout << setfill('-') << setw(109) << '-' << endl << endl;

		cout << "Joe : Sid    Frequency" << endl;

		// solution to print out map<string, int> adapted from https://stackoverflow.com/questions/30678405/stdcout-for-mapstring-int
		for (const auto& result : frequency) {
			std::cout << result.first << "        " << fixed << setprecision(1) << float(result.second) / champs * 100 << "%" << endl;
		}

		cout << endl << endl;

		if (champs == 1) {
			cout << "Because only 1 World Championship was played, Sid started throwing first to answer the question in Task 1:" << endl;
			cout << "  \"if Sid threw first in game one, by what score in sets would he expect to win?\"" << endl << endl;
		}
	}
	system("pause");
}

int Game::throwBull(Player* player) { // throw for bull

	int rate = player->getSuccessRate(); // player's accuracy rate

	int r = rand() % 100;

	if (r < rate) {
		player->incTargetHit(); // increment nr of times player hit the target
		return 50; // hit bullseye
	}
	else if (r >= rate && r < rate + (100 - rate) / 2) return 25; // missed inner but hit outer bullseye
	else /*(r >= rate + (100 - rate) / 2 && r < 100*/ return (rand() % 20 + 1); // missed bullseye
}

int Game::throwSingle(Player* player, int target) {// throwing for single

	int rate = player->getSuccessRate(); // player's accuracy rate

	int r = rand() % 100;

	if (target == 25) { // if player is aiming for outer bull
		if (r < rate) {
			player->incTargetHit(); // increment nr of times player hit the target
			return target; // hit outer bullseye
		}
		else if (r >= rate && r < (rate + 100) / 2) return 50; // missed outer but hit inner bullseye
		else return (rand() % 20 + 1); // missed outer but hit a single
	}
	else { // aiming for 1 to 20 single
		if (r < rate) {
			player->incTargetHit(); // increment nr of times player hit the target
			return target; // hit target
		}

		else if (r >= rate && r < (3 * rate + 100) / 4) return bd[0][target]; // missed target but hit its left neighbour
		else if (r >= (3 * rate + 100) / 4 && r < (rate + 100) / 2) return bd[1][target]; // missed target but hit its right neighbour
		else if (r >= (rate + 100) / 2 && r < (rate + 300) / 4) return 3 * target; // missed target but hit the treble ring
		else /*(r >= (rate + 300) / 4 && r < 100)*/return 2 * target; // missed target but hit the double ring
	}
}

int Game::throwDouble(Player* player, int target) {// throwing for double

	int rate = player->getSuccessRate(); // player's accuracy rate

	int r = rand() % 100;

	if (r < rate) {
		player->incTargetHit(); // increment nr of times player hit the target
		return 2 * target; // target hit
	}
	else if (r >= rate && r < (5 * rate + 100) / 6) return 0; // out of the board
	else if (r >= (5 * rate + 100) / 6 && r < (2 * rate + 100) / 3) return target; // missed target but hit single target
	else if (r >= (2 * rate + 100) / 3 && r < (rate + 100) / 2) return 2 * bd[0][target]; // missed target but hit its left neighbour double
	else if (r >= (rate + 100) / 2 && r < (rate + 200) / 3) return 2 * bd[1][target]; // missed target but hit its ritgh neighbour double
	else if (r >= (rate + 200) / 3 && r < (rate + 500) / 6) return bd[0][target]; // missed target but hit its left neighbour single
	else return bd[1][target]; // missed target but hit its right neighbour single
}

int Game::throwTreble(Player* player, int target) {// throwing for treble

	int rate = player->getSuccessRate(); // player's accuracy rate

	int r = rand() % 100;

	if (r < rate) {
		player->incTargetHit(); // increment nr of times player hit the target
		return 3 * target; // target hit
	}
	else if (r >= rate && r < (4 * rate + 100) / 5) return target; // missed target but hit single target
	else if (r >= (4 * rate + 100) / 5 && r < (3 * rate + 200) / 5) return 3 * bd[0][target]; // missed target but hit its left neighbour treble
	else if (r >= (3 * rate + 200) / 5 && r < (2 * rate + 300) / 5) return 3 * bd[1][target]; // missed target but hit its right neighbour treble
	else if (r >= (2 * rate + 300) / 5 && r < (rate + 400) / 5) return bd[0][target]; // missed target but hit its left neighbour single
	else return bd[1][target]; // missed target but hit its right neighbour single
}

void Game::populateStrategy() { // adds the strategy for each possible score to the strategy map

	// Based on the Michael Bartmess "Darts - 501 - Next Throw" Calculator, accessible at https://www.vcalc.com/wiki/MichaelBartmess/Darts+-+501+-+Next+Throw
	strategy.emplace(501, "T20 T20 T20");
	strategy.emplace(500, "T20 T20 T20");
	strategy.emplace(499, "T20 T20 T20");
	strategy.emplace(498, "T20 T20 T20");
	strategy.emplace(497, "T20 T20 T20");
	strategy.emplace(496, "T20 T20 T20");
	strategy.emplace(495, "T20 T20 T20");
	strategy.emplace(494, "T20 T20 T20");
	strategy.emplace(493, "T20 T20 T20");
	strategy.emplace(492, "T20 T20 T20");
	strategy.emplace(491, "T20 T20 T20");
	strategy.emplace(490, "T20 T20 T20");
	strategy.emplace(489, "T20 T20 T20");
	strategy.emplace(488, "T20 T20 T20");
	strategy.emplace(487, "T20 T20 T20");
	strategy.emplace(486, "T20 T20 T20");
	strategy.emplace(485, "T20 T20 T20");
	strategy.emplace(484, "T20 T20 T20");
	strategy.emplace(483, "T20 T20 T20");
	strategy.emplace(482, "T20 T20 T20");
	strategy.emplace(481, "T20 T20 T20");
	strategy.emplace(480, "T20 T20 T20");
	strategy.emplace(479, "T20 T20 T20");
	strategy.emplace(478, "T20 T20 T20");
	strategy.emplace(477, "T20 T20 T20");
	strategy.emplace(476, "T20 T20 T20");
	strategy.emplace(475, "T20 T20 T20");
	strategy.emplace(474, "T20 T20 T20");
	strategy.emplace(473, "T20 T20 T20");
	strategy.emplace(472, "T20 T20 T20");
	strategy.emplace(471, "T20 T20 T20");
	strategy.emplace(470, "T20 T20 T20");
	strategy.emplace(469, "T20 T20 T20");
	strategy.emplace(468, "T20 T20 T20");
	strategy.emplace(467, "T20 T20 T20");
	strategy.emplace(466, "T20 T20 T20");
	strategy.emplace(465, "T20 T20 T20");
	strategy.emplace(464, "T20 T20 T20");
	strategy.emplace(463, "T20 T20 T20");
	strategy.emplace(462, "T20 T20 T20");
	strategy.emplace(461, "T20 T20 T20");
	strategy.emplace(460, "T20 T20 T20");
	strategy.emplace(459, "T20 T20 T20");
	strategy.emplace(458, "T20 T20 T20");
	strategy.emplace(457, "T20 T20 T20");
	strategy.emplace(456, "T20 T20 T20");
	strategy.emplace(455, "T20 T20 T20");
	strategy.emplace(454, "T20 T20 T20");
	strategy.emplace(453, "T20 T20 T20");
	strategy.emplace(452, "T20 T20 T20");
	strategy.emplace(451, "T20 T20 T20");
	strategy.emplace(450, "T20 T20 T20");
	strategy.emplace(449, "T20 T20 T20");
	strategy.emplace(448, "T20 T20 T20");
	strategy.emplace(447, "T20 T20 T20");
	strategy.emplace(446, "T20 T20 T20");
	strategy.emplace(445, "T20 T20 T20");
	strategy.emplace(444, "T20 T20 T20");
	strategy.emplace(443, "T20 T20 T20");
	strategy.emplace(442, "T20 T20 T20");
	strategy.emplace(441, "T20 T20 T20");
	strategy.emplace(440, "T20 T20 T20");
	strategy.emplace(439, "T20 T20 T20");
	strategy.emplace(438, "T20 T20 T20");
	strategy.emplace(437, "T20 T20 T20");
	strategy.emplace(436, "T20 T20 T20");
	strategy.emplace(435, "T20 T20 T20");
	strategy.emplace(434, "T20 T20 T20");
	strategy.emplace(433, "T20 T20 T20");
	strategy.emplace(432, "T20 T20 T20");
	strategy.emplace(431, "T20 T20 T20");
	strategy.emplace(430, "T20 T20 T20");
	strategy.emplace(429, "T20 T20 T20");
	strategy.emplace(428, "T20 T20 T20");
	strategy.emplace(427, "T20 T20 T20");
	strategy.emplace(426, "T20 T20 T20");
	strategy.emplace(425, "T20 T20 T20");
	strategy.emplace(424, "T20 T20 T20");
	strategy.emplace(423, "T20 T20 T20");
	strategy.emplace(422, "T20 T20 T20");
	strategy.emplace(421, "T20 T20 T20");
	strategy.emplace(420, "T20 T20 T20");
	strategy.emplace(419, "T20 T20 T20");
	strategy.emplace(418, "T20 T20 T20");
	strategy.emplace(417, "T20 T20 T20");
	strategy.emplace(416, "T20 T20 T20");
	strategy.emplace(415, "T20 T20 T20");
	strategy.emplace(414, "T20 T20 T20");
	strategy.emplace(413, "T20 T20 T20");
	strategy.emplace(412, "T20 T20 T20");
	strategy.emplace(411, "T20 T20 T20");
	strategy.emplace(410, "T20 T20 T20");
	strategy.emplace(409, "T20 T20 T20");
	strategy.emplace(408, "T20 T20 T20");
	strategy.emplace(407, "T20 T20 T20");
	strategy.emplace(406, "T20 T20 T20");
	strategy.emplace(405, "T20 T20 T20");
	strategy.emplace(404, "T20 T20 T20");
	strategy.emplace(403, "T20 T20 T20");
	strategy.emplace(402, "T20 T20 T20");
	strategy.emplace(401, "T20 T20 T20");
	strategy.emplace(400, "T20 T20 T20");
	strategy.emplace(399, "T20 T20 T20");
	strategy.emplace(398, "T20 T20 T20");
	strategy.emplace(397, "T20 T20 T20");
	strategy.emplace(396, "T20 T20 T20");
	strategy.emplace(395, "T20 T20 T20");
	strategy.emplace(394, "T20 T20 T20");
	strategy.emplace(393, "T20 T20 T20");
	strategy.emplace(392, "T20 T20 T20");
	strategy.emplace(391, "T20 T20 T20");
	strategy.emplace(390, "T20 T20 T20");
	strategy.emplace(389, "T20 T20 T20");
	strategy.emplace(388, "T20 T20 T20");
	strategy.emplace(387, "T20 T20 T20");
	strategy.emplace(386, "T20 T20 T20");
	strategy.emplace(385, "T20 T20 T20");
	strategy.emplace(384, "T20 T20 T20");
	strategy.emplace(383, "T20 T20 T20");
	strategy.emplace(382, "T20 T20 T20");
	strategy.emplace(381, "T20 T20 T20");
	strategy.emplace(380, "T20 T20 T20");
	strategy.emplace(379, "T20 T20 T20");
	strategy.emplace(378, "T20 T20 T20");
	strategy.emplace(377, "T20 T20 T20");
	strategy.emplace(376, "T20 T20 T20");
	strategy.emplace(375, "T20 T20 T20");
	strategy.emplace(374, "T20 T20 T20");
	strategy.emplace(373, "T20 T20 T20");
	strategy.emplace(372, "T20 T20 T20");
	strategy.emplace(371, "T20 T20 T20");
	strategy.emplace(370, "T20 T20 T20");
	strategy.emplace(369, "T20 T20 T20");
	strategy.emplace(368, "T20 T20 T20");
	strategy.emplace(367, "T20 T20 T20");
	strategy.emplace(366, "T20 T20 T20");
	strategy.emplace(365, "T20 T20 T20");
	strategy.emplace(364, "T20 T20 T20");
	strategy.emplace(363, "T20 T20 T20");
	strategy.emplace(362, "T20 T20 T20");
	strategy.emplace(361, "T20 T20 T20");
	strategy.emplace(360, "T20 T20 T20");
	strategy.emplace(359, "T20 T20 T20");
	strategy.emplace(358, "T20 T20 T20");
	strategy.emplace(357, "T20 T20 T20");
	strategy.emplace(356, "T20 T20 T20");
	strategy.emplace(355, "T20 T20 T20");
	strategy.emplace(354, "T20 T20 T20");
	strategy.emplace(353, "T20 T20 T20");
	strategy.emplace(352, "T20 T20 T20");
	strategy.emplace(351, "T20 T20 T20");
	strategy.emplace(350, "T20 T20 T20");
	strategy.emplace(349, "T20 T20 T20");
	strategy.emplace(348, "T20 T20 T20");
	strategy.emplace(347, "T20 T20 T20");
	strategy.emplace(346, "T20 T20 T20");
	strategy.emplace(345, "T20 T20 T20");
	strategy.emplace(344, "T20 T20 T20");
	strategy.emplace(343, "T20 T20 T20");
	strategy.emplace(342, "T20 T20 T20");
	strategy.emplace(341, "T20 T20 T20");
	strategy.emplace(340, "T20 T20 T20");
	strategy.emplace(339, "T20 T20 T20");
	strategy.emplace(338, "T20 T20 T20");
	strategy.emplace(337, "T20 T20 T20");
	strategy.emplace(336, "T20 T20 T20");
	strategy.emplace(335, "T20 T20 T20");
	strategy.emplace(334, "T20 T20 T20");
	strategy.emplace(333, "T20 T20 T20");
	strategy.emplace(332, "T20 T20 T20");
	strategy.emplace(331, "T20 T20 T20");
	strategy.emplace(330, "T20 T20 T20");
	strategy.emplace(329, "T20 T20 T20");
	strategy.emplace(328, "T20 T20 T20");
	strategy.emplace(327, "T20 T20 T20");
	strategy.emplace(326, "T20 T20 T20");
	strategy.emplace(325, "T20 T20 T20");
	strategy.emplace(324, "T20 T20 T20");
	strategy.emplace(323, "T20 T20 T20");
	strategy.emplace(322, "T20 T20 T20");
	strategy.emplace(321, "T20 T20 T20");
	strategy.emplace(320, "T20 T20 T20");
	strategy.emplace(319, "T20 T20 T20");
	strategy.emplace(318, "T20 T20 T20");
	strategy.emplace(317, "T20 T20 T20");
	strategy.emplace(316, "T20 T20 T20");
	strategy.emplace(315, "T20 T20 T20");
	strategy.emplace(314, "T20 T20 T20");
	strategy.emplace(313, "T20 T20 T20");
	strategy.emplace(312, "T20 T20 T20");
	strategy.emplace(311, "T20 T20 T20");
	strategy.emplace(310, "T20 T20 T20");
	strategy.emplace(309, "T20 T20 T20");
	strategy.emplace(308, "T20 T20 T20");
	strategy.emplace(307, "T20 T20 T20");
	strategy.emplace(306, "T20 T20 T20");
	strategy.emplace(305, "T20 T20 T20");
	strategy.emplace(304, "T20 T20 T20");
	strategy.emplace(303, "T20 T20 T20");
	strategy.emplace(302, "T20 T20 T20");
	strategy.emplace(301, "T20 T20 T20");
	strategy.emplace(300, "T20 T20 T20");
	strategy.emplace(299, "T20 T20 T20");
	strategy.emplace(298, "T20 T20 T20");
	strategy.emplace(297, "T20 T20 T20");
	strategy.emplace(296, "T20 T20 T20");
	strategy.emplace(295, "T20 T20 T20");
	strategy.emplace(294, "T20 T20 T20");
	strategy.emplace(293, "T20 T20 T20");
	strategy.emplace(292, "T20 T20 T20");
	strategy.emplace(291, "T20 T20 T20");
	strategy.emplace(290, "T20 T20 T20");
	strategy.emplace(289, "T20 T20 T20");
	strategy.emplace(288, "T20 T20 T20");
	strategy.emplace(287, "T20 T20 T20");
	strategy.emplace(286, "T20 T20 T20");
	strategy.emplace(285, "T20 T20 T20");
	strategy.emplace(284, "T20 T20 T20");
	strategy.emplace(283, "T20 T20 T20");
	strategy.emplace(282, "T20 T20 T20");
	strategy.emplace(281, "T20 T20 T20");
	strategy.emplace(280, "T20 T20 T20");
	strategy.emplace(279, "T20 T20 T20");
	strategy.emplace(278, "T20 T20 T20");
	strategy.emplace(277, "T20 T20 T20");
	strategy.emplace(276, "T20 T20 T20");
	strategy.emplace(275, "T20 T20 T20");
	strategy.emplace(274, "T20 T20 T20");
	strategy.emplace(273, "T20 T20 T20");
	strategy.emplace(272, "T20 T20 T20");
	strategy.emplace(271, "T20 T20 T20");
	strategy.emplace(270, "T20 T20 T20");
	strategy.emplace(269, "T20 T20 T20");
	strategy.emplace(268, "T20 T20 T20");
	strategy.emplace(267, "T20 T20 T20");
	strategy.emplace(266, "T20 T20 T20");
	strategy.emplace(265, "T20 T20 T20");
	strategy.emplace(264, "T20 T20 T20");
	strategy.emplace(263, "T20 T20 T20");
	strategy.emplace(262, "T20 T20 T20");
	strategy.emplace(261, "T20 T20 T20");
	strategy.emplace(260, "T20 T20 T20");
	strategy.emplace(259, "T20 T20 T20");
	strategy.emplace(258, "T20 T20 T20");
	strategy.emplace(257, "T20 T20 T20");
	strategy.emplace(256, "T20 T20 T20");
	strategy.emplace(255, "T20 T20 T20");
	strategy.emplace(254, "T20 T20 T20");
	strategy.emplace(253, "T20 T20 T20");
	strategy.emplace(252, "T20 T20 T20");
	strategy.emplace(251, "T20 T20 T20");
	strategy.emplace(250, "T20 T20 T20");
	strategy.emplace(249, "T20 T20 T20");
	strategy.emplace(248, "T20 T20 T20");
	strategy.emplace(247, "T20 T20 T20");
	strategy.emplace(246, "T20 T20 T20");
	strategy.emplace(245, "T20 T20 T20");
	strategy.emplace(244, "T20 T20 T20");
	strategy.emplace(243, "T20 T20 T20");
	strategy.emplace(242, "T20 T20 T20");
	strategy.emplace(241, "T20 T20 T20");
	strategy.emplace(240, "T20 T20 T20");
	strategy.emplace(239, "T20 T20 T20");
	strategy.emplace(238, "T20 T20 T20");
	strategy.emplace(237, "T20 T20 T20");
	strategy.emplace(236, "T20 T20 T20");
	strategy.emplace(235, "T20 T20 T20");
	strategy.emplace(234, "T20 T20 T20");
	strategy.emplace(233, "T20 T20 T20");
	strategy.emplace(232, "T20 T20 T20");
	strategy.emplace(231, "T20 T20 T20");
	strategy.emplace(230, "T20 T20 T20");
	strategy.emplace(229, "T20 T20 T20");
	strategy.emplace(228, "T20 T20 T20");
	strategy.emplace(227, "T20 T20 T20");
	strategy.emplace(226, "T20 T20 T20");
	strategy.emplace(225, "T20 T20 T20");
	strategy.emplace(224, "T20 T20 T20");
	strategy.emplace(223, "T20 T20 T20");
	strategy.emplace(222, "T20 T20 T20");
	strategy.emplace(221, "T20 T20 T20");
	strategy.emplace(220, "T20 T20 T20");
	strategy.emplace(219, "T20 T20 T20");
	strategy.emplace(218, "T20 T20 T20");
	strategy.emplace(217, "T20 T20 T20");
	strategy.emplace(216, "T20 T20 T20");
	strategy.emplace(215, "T20 T20 T20");
	strategy.emplace(214, "T20 T20 T20");
	strategy.emplace(213, "T20 T20 T20");
	strategy.emplace(212, "T20 T20 T20");
	strategy.emplace(211, "T20 T20 T19");
	strategy.emplace(210, "T20 T20 T19");
	strategy.emplace(209, "T20 T20 T19");
	strategy.emplace(208, "T20 T19 T19");
	strategy.emplace(207, "T20 T19 T19");
	strategy.emplace(206, "T20 T19 T19");
	strategy.emplace(205, "T19 T19 T19");
	strategy.emplace(204, "T20 T20 D10");
	strategy.emplace(203, "T19 T19 T19");
	strategy.emplace(202, "T20 T20 B");
	strategy.emplace(201, "T20 T19 D10");
	strategy.emplace(200, "T19 T19 T18");
	strategy.emplace(199, "T19 T19 T7");
	strategy.emplace(198, "T20 T20 S14");
	strategy.emplace(197, "T20 T16 T19");
	strategy.emplace(196, "T20 T20 S12");
	strategy.emplace(195, "T19 T19 S17");
	strategy.emplace(194, "T20 T16 T18");
	strategy.emplace(193, "T19 T18 B");
	strategy.emplace(192, "T20 T20 D20");
	strategy.emplace(191, "T20 T17 T16");
	strategy.emplace(190, "T20 T20 D19");
	strategy.emplace(189, "T20 T19 D20");
	strategy.emplace(188, "T20 T20 D18");
	strategy.emplace(187, "T20 T19 D19");
	strategy.emplace(186, "T20 T20 D17");
	strategy.emplace(185, "T20 T19 D18");
	strategy.emplace(184, "T20 T20 D16");
	strategy.emplace(183, "T20 T19 D17");
	strategy.emplace(182, "T20 T20 D15");
	strategy.emplace(181, "T20 T19 D16");
	strategy.emplace(180, "T20 T20 D14");
	strategy.emplace(179, "T20 T19 D15");
	strategy.emplace(178, "T20 T20 D13");
	strategy.emplace(177, "T20 T19 D14");
	strategy.emplace(176, "T20 T20 D12");
	strategy.emplace(175, "T20 T19 D13");
	strategy.emplace(174, "T20 T20 D11");
	strategy.emplace(173, "T20 T19 D12");
	strategy.emplace(172, "T20 T20 D10");
	strategy.emplace(171, "T20 T20 S19");
	strategy.emplace(170, "T20 T20 B");
	strategy.emplace(169, "T20 T20 S17");
	strategy.emplace(168, "T20 T20 S16");
	strategy.emplace(167, "T20 T19 B");
	strategy.emplace(166, "T20 T20 S14");
	strategy.emplace(165, "T20 T19 S16");
	strategy.emplace(164, "T20 T18 B");
	strategy.emplace(163, "T20 T19 S14");
	strategy.emplace(162, "T20 T20 S10");
	strategy.emplace(161, "T20 T17 B");
	strategy.emplace(160, "T20 T20 D20");
	strategy.emplace(159, "T20 T19 S10");
	strategy.emplace(158, "T20 T20 D19");
	strategy.emplace(157, "T20 T19 D20");
	strategy.emplace(156, "T20 T20 D18");
	strategy.emplace(155, "T20 T19 D19");
	strategy.emplace(154, "T20 T18 D20");
	strategy.emplace(153, "T20 T19 D18");
	strategy.emplace(152, "T20 T20 D16");
	strategy.emplace(151, "T20 T17 D20");
	strategy.emplace(150, "T20 T18 D18");
	strategy.emplace(149, "T20 T19 D16");
	strategy.emplace(148, "T20 T16 D20");
	strategy.emplace(147, "T20 T17 D18");
	strategy.emplace(146, "T20 T18 D16");
	strategy.emplace(145, "T20 T15 D20");
	strategy.emplace(144, "T20 T20 D12");
	strategy.emplace(143, "T20 T17 D16");
	strategy.emplace(142, "T20 T14 D20");
	strategy.emplace(141, "T20 T19 D12");
	strategy.emplace(140, "T20 T16 D16");
	strategy.emplace(139, "T19 T14 D20");
	strategy.emplace(138, "T20 T18 D12");
	strategy.emplace(137, "T19 T16 D16");
	strategy.emplace(136, "T20 T20 D8");
	strategy.emplace(135, "T20 T17 D12");
	strategy.emplace(134, "T20 T14 D16");
	strategy.emplace(133, "T20 T19 D8");
	strategy.emplace(132, "T20 T16 D12");
	strategy.emplace(131, "T20 T13 D16");
	strategy.emplace(130, "T20 T20 D5");
	strategy.emplace(129, "T19 T16 D12");
	strategy.emplace(128, "T18 T14 D16");
	strategy.emplace(127, "T20 T17 D8");
	strategy.emplace(126, "T19 T19 D6");
	strategy.emplace(125, "S25 T20 D20");
	strategy.emplace(124, "T20 T16 D8");
	strategy.emplace(123, "T19 T16 D9");
	strategy.emplace(122, "T18 T20 D4");
	strategy.emplace(121, "T17 T10 D20");
	strategy.emplace(120, "T20 S20 D20");
	strategy.emplace(119, "T19 T10 D16");
	strategy.emplace(118, "T20 S18 D20");
	strategy.emplace(117, "T20 S17 D20");
	strategy.emplace(116, "T20 S16 D20");
	strategy.emplace(115, "T20 S15 D20");
	strategy.emplace(114, "T20 S14 D20");
	strategy.emplace(113, "T20 S13 D20");
	strategy.emplace(112, "T20 S12 D20");
	strategy.emplace(111, "T20 S19 D16");
	strategy.emplace(110, "T20 S18 D16");
	strategy.emplace(109, "T19 S20 D16");
	strategy.emplace(108, "T20 S16 D16");
	strategy.emplace(107, "T19 S18 D16");
	strategy.emplace(106, "T20 S14 D16");
	strategy.emplace(105, "T19 S16 D16");
	strategy.emplace(104, "T18 S18 D16");
	strategy.emplace(103, "T20 S3 D20");
	strategy.emplace(102, "T20 S10 D16");
	strategy.emplace(101, "T20 S1 D20");
	strategy.emplace(100, "T20 D20");
	strategy.emplace(99, "T19 S10 D16");
	strategy.emplace(98, "T20 D19");
	strategy.emplace(97, "T19 D20");
	strategy.emplace(96, "T20 D18");
	strategy.emplace(95, "T19 D19");
	strategy.emplace(94, "T18 D20");
	strategy.emplace(93, "T19 D18");
	strategy.emplace(92, "T20 D16");
	strategy.emplace(91, "T17 D20");
	strategy.emplace(90, "T20 D15");
	strategy.emplace(89, "T19 D16");
	strategy.emplace(88, "T16 D20");
	strategy.emplace(87, "T17 D18");
	strategy.emplace(86, "T18 D16");
	strategy.emplace(85, "T15 D20");
	strategy.emplace(84, "T20 D12");
	strategy.emplace(83, "T17 D16");
	strategy.emplace(82, "T14 D20");
	strategy.emplace(81, "T19 D12");
	strategy.emplace(80, "T20 D10");
	strategy.emplace(79, "T19 D11");
	strategy.emplace(78, "T18 D12");
	strategy.emplace(77, "T19 D10");
	strategy.emplace(76, "T20 D8");
	strategy.emplace(75, "T17 D12");
	strategy.emplace(74, "T14 D16");
	strategy.emplace(73, "T19 D8");
	strategy.emplace(72, "T16 D12");
	strategy.emplace(71, "T13 D16");
	strategy.emplace(70, "T10 D20");
	strategy.emplace(69, "T15 D12");
	strategy.emplace(68, "T20 D4");
	strategy.emplace(67, "T17 D8");
	strategy.emplace(66, "T10 D18");
	strategy.emplace(65, "T19 D4");
	strategy.emplace(64, "T16 D8");
	strategy.emplace(63, "T13 D12");
	strategy.emplace(62, "T10 D16");
	strategy.emplace(61, "T15 D8");
	strategy.emplace(60, "S20 D20");
	strategy.emplace(59, "S19 D20");
	strategy.emplace(58, "S18 D20");
	strategy.emplace(57, "S17 D20");
	strategy.emplace(56, "S16 D20");
	strategy.emplace(55, "S15 D20");
	strategy.emplace(54, "S14 D20");
	strategy.emplace(53, "S13 D20");
	strategy.emplace(52, "S12 D20");
	strategy.emplace(51, "S19 D16");
	strategy.emplace(50, "S10 D20");
	strategy.emplace(49, "S17 D16");
	strategy.emplace(48, "S16 D16");
	strategy.emplace(47, "S15 D16");
	strategy.emplace(46, "S6 D20");
	strategy.emplace(45, "S13 D16");
	strategy.emplace(44, "S12 D16");
	strategy.emplace(43, "S3 D20");
	strategy.emplace(42, "S10 D16");
	strategy.emplace(41, "S9 D16");
	strategy.emplace(40, "D20 ");
	strategy.emplace(39, "S7 D16");
	strategy.emplace(38, "D19");
	strategy.emplace(37, "S5 D16");
	strategy.emplace(36, "D18 ");
	strategy.emplace(35, "S3 D16");
	strategy.emplace(34, "D17");
	strategy.emplace(33, "S17 D8");
	strategy.emplace(32, "D16");
	strategy.emplace(31, "S15 D8");
	strategy.emplace(30, "D15");
	strategy.emplace(29, "S13 D8");
	strategy.emplace(28, "D14");
	strategy.emplace(27, "S11 D8");
	strategy.emplace(26, "D13");
	strategy.emplace(25, "S9 D8");
	strategy.emplace(24, "D12");
	strategy.emplace(23, "S7 D8");
	strategy.emplace(22, "D11");
	strategy.emplace(21, "S5 D8");
	strategy.emplace(20, "D10");
	strategy.emplace(19, "S3 D8");
	strategy.emplace(18, "D9");
	strategy.emplace(17, "S1 D8");
	strategy.emplace(16, "D8");
	strategy.emplace(15, "S7 D4");
	strategy.emplace(14, "D7");
	strategy.emplace(13, "S5 D4");
	strategy.emplace(12, "D6");
	strategy.emplace(11, "S3 D4");
	strategy.emplace(10, "D5");
	strategy.emplace(9, "S1 D4");
	strategy.emplace(8, "D4");
	strategy.emplace(7, "S3 D2");
	strategy.emplace(6, "D3");
	strategy.emplace(5, "S1 D2");
	strategy.emplace(4, "D2");
	strategy.emplace(3, "S1 D1");
	strategy.emplace(2, "D1");
}

string Game::searchStrategy(int score) { // find the player's best strategy according to his score, using the 'strategy' map
	return strategy[score];
}

vector<string> Game::parseStrategy(string strat) { // func to parse the strategy obtained by searchStrategy(score)
												   // splits a string like "T20 T20 T20" into a vector<string> like {"T20", "T20", "T20"}
	vector<string> parsed; // vector to store 'decoded' strategy
	istringstream temp(strat); // 'Input string stream' to store temporary string to be splitted by spaces into a vector of strings

	for (string str; temp >> str;) { // operator >> will split 'temp' string by spaces
		parsed.push_back(str);
	}

	return parsed;
}

int Game::playStrategy(Player* player) { // play round using Enhanced Strategy (task 2)

	// vector to store returned value from strategy functions, eg: {"T20", "T20", "T20"}
	vector<string> darts = parseStrategy(searchStrategy(player->getScore()));

	int localDartsThrown = 0; // to store nr of darts thrown in this round
	int roundScore = 0; // this round score

	bool strategyStillValid = true; // in case player miss target, this var will turn false to force the strategy to be recalculated

	for (unsigned int i = 0; i < darts.size(); i++) // throw dart 3 times (or less if the strategy returned allow player to finish with less than 3 darts)
	{
		if (!strategyStillValid) { // if player missed a target, i.e. first strategy is not valid anymore, recalculate strategy and make some ajustments 
			strategyStillValid = true;

			darts = parseStrategy(searchStrategy(player->getScore() - roundScore));

			if (localDartsThrown == 1) {// 2 darts left
				if (darts.size() == 1) {
					i = 0;
				}
				else if (darts.size() == 2) { // player can finish in 2 darts
					i = 0;
				}
				else if (darts.size() == 3) {//"T20 T20"
					darts.pop_back(); // remove the last throw from the strategy cause player only have 2 throws left
					i = 0; //to start from the first strategy (but it's the second dart)
				}
				else {
					cout << "Err"; // for debug purposes
				}
			}
			else if (localDartsThrown == 2) { // 1 dart left
				if (darts.size() == 1) {
					i = 0;
				}

				else if (darts.size() == 2) {
					darts.pop_back();
					i = 0;
				}
				else if (darts.size() == 3) {
					darts.pop_back();
					darts.pop_back();
					i = 0;
				}
				else {
					cout << "Err"; // for debug purposes
				}
			}
			else cout << "Something went wrong in the enhanced strategy cause I have more darts left than i should" << endl; // for debug purposes
		}

		player->incDartsThrown(); // increment nr of times player throw dart
		localDartsThrown++; // increment nr of darts thrown in this round

		int dartScore = 0; // to store score of each dart thrown

		if (darts[i].length() == 1) { // if the length of strategy string is 1, it must be "B" => throw at bull
			dartScore = throwBull(player);

			if (dartScore != 50) strategyStillValid = false;
		}

		else { // convert string into throw, eg "T20" => throwTreble(20)
			int number = 0;

			if (darts[i].length() == 2) number = stoi(darts[i].substr(1, 1)); // eg: "D6" => throwDouble(6)
			else /*(darts[i].length() == 3)*/ number = stoi(darts[i].substr(1, 2)); // eg: "D16" => throwDouble(16)

			switch (darts[i][0]) {
			case 'S': // it's single		
				dartScore = throwSingle(player, number);

				if (dartScore != number) strategyStillValid = false;
				break;

			case 'D': // it's double
				dartScore = throwDouble(player, number);

				if (dartScore != 2 * number) strategyStillValid = false;
				break;

			case 'T': // it's treble
				dartScore = throwTreble(player, number);

				if (dartScore != 3 * number) strategyStillValid = false;
				break;

			default:
				cout << "Err"; // for debug purposes
				break;
			}
		}
		roundScore += dartScore; // update round score with this dart's score

		if (player->getScore() - roundScore == 0) {
			if (!strategyStillValid) { // if player missed the target for last dart but still managed to finish

				if (darts[i][0] == 'S' || darts[i][0] == 'T') { // check what was the last 
					roundScore = 0; // if player is finishing with a treble or a single,
									//  the score is invalid and this round's score is discarded
				}
				else {
					cout << "Err"; // for debug purposes
				}

			}
			break; // player win or score is invalid because he didnt finish with bull or double
		}
		else if (player->getScore() - roundScore < 2) {
			roundScore = 0;
			break; // round is invalid
		}
	}
	player->estSuccessRate(); //after each round, calc the new estimated success rate

	return roundScore; // return this round's score
}

void Game::playInteractive() {
	string name = ""; // stores real player's name
	int opponent = 0; // to choose the bot which will play against user
	int difficulty = 0;

	cout << endl << "Enter your name: ";
	cin >> name;

	cout << endl << "Who are you going to play with?" << endl << endl;
	cout << "  1: Joe (71%)" << endl;
	cout << "  2: Sid (73%)" << endl << endl;
	do {
		cout << "Option> ";
		cin >> opponent;

		// prevents bad input to mess with cin
		if (cin.fail()) {
			cin.clear();
			cin.ignore(numeric_limits<streamsize>::max(), '\n');
		}
	} while (opponent != 1 && opponent != 2); // keep asking for input if input is not valid

	// Convert user selection into the appropriate index to be used below with 'player[opponent]'
	if (opponent == 1) opponent = 0; // if user chose Joe => opponent="Joe's index"
	else opponent = 1; //opponent is 2. if user chose Sid => opponent="Sid's index"

	// creates Interactive object 'inter' with pointer to the chosen bot and the user's name
	Interactive inter(player[opponent], name);

	cout << endl << "What's the level of difficulty?" << endl << endl;
	cout << "  1: Easy" << endl;
	cout << "  2: Medium" << endl;
	cout << "  3: Hard" << endl << endl;
	do {
		cout << "Option> ";
		cin >> difficulty;

		// prevents bad input to mess with cin
		if (cin.fail()) {
			cin.clear();
			cin.ignore(numeric_limits<streamsize>::max(), '\n');
		}
	} while (difficulty != 1 && difficulty != 2 && difficulty != 3); // keep asking for input if input is not valid

	switch (difficulty) {
	case 1:
		inter.setHumRate(80); // 80% success rate
		break;
	case 2:
		inter.setHumRate(player[opponent]->getSuccessRate()); // same success rate as opponent
		break;
	case 3:
		inter.setHumRate(60); // 60% success rate
		break;
	default:
		cout << "Err"; // debug purposes
		break;
	}

	inter.playIntMatch();
}