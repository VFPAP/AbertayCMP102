#pragma once

#include <string>

using namespace std;

class Player
{
private:
	string name = "";		// player's name
	int successRate = 0;    // fixed success rate
	double estSuccRate = 0; // estimated success rate
	int score = 0;          // score
	int roundsPlayed = 0;   // nr of rounds played (used to calc rounds per game)
	int dartsThrown = 0;    // nr of darts thrown (used to calc estSuccRate - see estSuccessRate() func prototype)
	int targetHit = 0;      // nr of times target was hit, i.e. hit bull if target was bull
	int wins = 0;           // nr of times player won games (used when playing multiple games)

public:
	Player(string, int);		// constructor
	~Player();					// destructor

	string getName();			// getter for name
	int getSuccessRate();		// getter for fixed success rate
	void setSuccessRate(int);	// setter for fixed success rate
	int getScore();				// getter for score
	void setScore(int);			// setter to update score
	void incRoundsPlayed();		// increment rounds played by 1
	int getRoundsPlayed();		// getter for nr of rounds played (used to calc rounds per game)
	void incDartsThrown();		// increment darts thrown played by 1
	int getDartsThrown();		// getter for nr of darts thrown
	void estSuccessRate();		// calc estimated success rate 
	double getEstSuccessRate();	// getter for estimated success rate
	void incTargetHit();		// increment targetHit by 1
	int getWins();				// getter for nr of times player won a game (used when playing multiple games)
	void incWins();				// increment games won by 1
};
