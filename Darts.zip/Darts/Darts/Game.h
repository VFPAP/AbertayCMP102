#pragma once

#include "Player.h"
#include <iostream>
#include <vector>
#include <iomanip>
#include <map>
#include <sstream> // used to split strings by spaces

class Game
{
private:
	vector<Player*> player;		// vector to store pointers to Player objects 
	const int game = 501;		// game type (used to reset score between games)
	string winner = "";			// to store the name of the winner
	map<string, int> frequency;	// to store frequencies in World Championships mode
	int champs = 0;				// nr of World Championships played

public:	               //  1   2   3   4   5   6   7   8   9  10  11 12 13  14  15 16 17 18 19  20
	int bd[2][21] = { {0, 20, 15, 17, 18, 12, 13, 19, 16, 14, 6,  8,  9, 4, 11, 10, 7, 2, 1, 3, 5},
					  {0, 18, 17, 19, 13, 20, 10, 16, 11, 12, 15, 14, 5, 6, 9,  2,  8, 3, 4, 7, 1} };

	map<int, string> strategy;				// map container to store the strategy for each score

	Game();									// default constructor needed for the derived class Interactive
	Game(Player*, Player*);					// constructor
	~Game();								// destructor

	string getWinner();						// getter for winner
	void setWinner(string);					// setter for winner
	void resetPlayersScores();				// resets scores of both players
	void playSingle();						// play a normal game
	void playFinal();						// play World Championships 
	string playMatch();						// play match of World Championships 
	string playSet();						// play set of World Championships
	string playGame();						// play game of World Championships
	void playMulti();						// simulate a nr of single games
	void playRound();						// calls func to decide player's strategy (playStrategy()) and plays the round accordingly
	int throwBull(Player*);					// throw to bull
	int throwSingle(Player*, int);			// throw to single
	void printResults(int);					// print results at the end of the game
	int throwDouble(Player*, int);			// throw to doubles ring
	int throwTreble(Player*, int);			// throw to trebles ring
	void populateStrategy();				// adds the strategy for each possible score to the strategy map
	string searchStrategy(int);				// find the player's best strategy according to his score, using the 'strategy' map
	vector<string> parseStrategy(string);	// func to 'decode' the strategy obtained by searchStrategy(score)
	int playStrategy(Player*);				// func created for task 2 (Enhanced Strategy). Decides what's the best strategy for player
	void playInteractive();					// func created for task 3 (Interactive Game). Creates an interactive game with the chosen bot and the user's name
};
