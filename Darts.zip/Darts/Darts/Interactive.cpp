﻿#include "Interactive.h"

Interactive::Interactive(Player* b, string human) {
	bot = b;
	humName = human;

	humScore = game;
	bot->setScore(game);

	populateValidDarts();
	populateStrategy();
}

Interactive::~Interactive() {}

void Interactive::setHumRate(int rate) {
	humRate = rate;
}

void Interactive::populateValidDarts() {

	validDarts.push_back("B");
	validDarts.push_back("S1");
	validDarts.push_back("S2");
	validDarts.push_back("S3");
	validDarts.push_back("S4");
	validDarts.push_back("S5");
	validDarts.push_back("S6");
	validDarts.push_back("S7");
	validDarts.push_back("S8");
	validDarts.push_back("S9");
	validDarts.push_back("S10");
	validDarts.push_back("S11");
	validDarts.push_back("S12");
	validDarts.push_back("S13");
	validDarts.push_back("S14");
	validDarts.push_back("S15");
	validDarts.push_back("S16");
	validDarts.push_back("S17");
	validDarts.push_back("S18");
	validDarts.push_back("S19");
	validDarts.push_back("S20");
	validDarts.push_back("S25");
	validDarts.push_back("D1");
	validDarts.push_back("D2");
	validDarts.push_back("D3");
	validDarts.push_back("D4");
	validDarts.push_back("D5");
	validDarts.push_back("D6");
	validDarts.push_back("D7");
	validDarts.push_back("D8");
	validDarts.push_back("D9");
	validDarts.push_back("D10");
	validDarts.push_back("D11");
	validDarts.push_back("D12");
	validDarts.push_back("D13");
	validDarts.push_back("D14");
	validDarts.push_back("D15");
	validDarts.push_back("D16");
	validDarts.push_back("D17");
	validDarts.push_back("D18");
	validDarts.push_back("D19");
	validDarts.push_back("D20");
	validDarts.push_back("T1");
	validDarts.push_back("T2");
	validDarts.push_back("T3");
	validDarts.push_back("T4");
	validDarts.push_back("T5");
	validDarts.push_back("T6");
	validDarts.push_back("T7");
	validDarts.push_back("T8");
	validDarts.push_back("T9");
	validDarts.push_back("T10");
	validDarts.push_back("T11");
	validDarts.push_back("T12");
	validDarts.push_back("T13");
	validDarts.push_back("T14");
	validDarts.push_back("T15");
	validDarts.push_back("T16");
	validDarts.push_back("T17");
	validDarts.push_back("T18");
	validDarts.push_back("T19");
	validDarts.push_back("T20");
}

bool Interactive::validDartChoice(string dart) {

	// if user's input is a valid dart, return true
	if (find(validDarts.begin(), validDarts.end(), dart) != validDarts.end()) return true;
	else return false;
}

void Interactive::enableHints() {
	int hnts = 0;
	cout << endl << "Do you want to enable hints? With hints enabled you are 10% less likely to hit the target!" << endl << endl;
	cout << "  1: Yes" << endl;
	cout << "  2: No" << endl << endl;
	do
	{
		cout << "Option> ";
		cin >> hnts;

		// prevents bad input to mess with cin
		if (cin.fail()) {
			cin.clear();
			cin.ignore(numeric_limits<streamsize>::max(), '\n');
		}

	} while (hnts != 1 && hnts != 2);

	if (hnts == 1) {
		humRate -= 10;
		hints = true;
	}
	else hints = false;
}

void Interactive::showHint(int roundScore) {
	vector<string> hintDarts = parseStrategy(searchStrategy(humScore - roundScore));

	cout << "Hint: " << hintDarts[0] << endl;
}

int Interactive::throwBull() {
	//int rate = 80;

	int r = rand() % 100;

	if (r < humRate) return 50; // hit bullseye
	else if (r >= humRate && r < humRate + (100 - humRate) / 2) return 25; // missed inner but hit outer bullseye
	else /*(r >= rate + (100 - rate) / 2 && r < 100*/ return (rand() % 20 + 1); // missed bullseye
}

int Interactive::throwSingle(int target) {
	//int rate = 80;

	int r = rand() % 100;

	if (target == 25) {
		if (r < humRate) return target; // hit outer bullseye
		else if (r >= humRate && r < (humRate + 100) / 2) return 50; // missed outer but hit inner bullseye
		else return (rand() % 20 + 1); // missed outer but hit a single
	}
	else {

		// 1 to 20 single
		if (r < humRate) return target; // hit target
		else if (r >= humRate && r < (3 * humRate + 100) / 4) return bd[0][target]; // missed target but hit its left neighbour
		else if (r >= (3 * humRate + 100) / 4 && r < (humRate + 100) / 2) return bd[1][target]; // missed target but hit its right neighbour
		else if (r >= (humRate + 100) / 2 && r < (humRate + 300) / 4) return 3 * target; // missed target but hit the treble ring
		else /*(r >= (rate + 300) / 4 && r < 100)*/return 2 * target; // missed target but hit the double ring
	}
}

int Interactive::throwDouble(int target) {
	//int rate = 80;

	int r = rand() % 100;

	if (r < humRate) return 2 * target; // target hit
	else if (r >= humRate && r < (5 * humRate + 100) / 6) return 0; // out of the board
	else if (r >= (5 * humRate + 100) / 6 && r < (2 * humRate + 100) / 3) return target; // missed target but hit single target
	else if (r >= (2 * humRate + 100) / 3 && r < (humRate + 100) / 2) return 2 * bd[0][target]; // missed target but hit its left neighbour double
	else if (r >= (humRate + 100) / 2 && r < (humRate + 200) / 3) return 2 * bd[1][target]; // missed target but hit its ritgh neighbour double
	else if (r >= (humRate + 200) / 3 && r < (humRate + 500) / 6) return bd[0][target]; // missed target but hit its left neighbour single
	else return bd[1][target]; // missed target but hit its right neighbour single
}

int Interactive::throwTreble(int target) {
	//int rate = 80;

	int r = rand() % 100;

	if (r < humRate) return 3 * target; // target hit
	else if (r >= humRate && r < (4 * humRate + 100) / 5) return target; // missed target but hit single target
	else if (r >= (4 * humRate + 100) / 5 && r < (3 * humRate + 200) / 5) return 3 * bd[0][target]; // missed target but hit its left neighbour treble
	else if (r >= (3 * humRate + 200) / 5 && r < (2 * humRate + 300) / 5) return 3 * bd[1][target]; // missed target but hit its right neighbour treble
	else if (r >= (2 * humRate + 300) / 5 && r < (humRate + 400) / 5) return bd[0][target]; // missed target but hit its left neighbour single
	else return bd[1][target]; // missed target but hit its right neighbour single
}

void Interactive::playIntMatch() {

	char first;
	string result = "";
	int humWinSet = 0;
	int botWinSet = 0;

	enableHints(); // sets 'hints' to true if human wants hints

	system("cls");

	cout << "Both players throw \"nearest the bull\" to see who goes first." << endl << endl;
	cout << "[Press ENTER to Throw]" << endl;
	system("pause");

	cout << endl << bot->getName() << " is throwing..." << endl;
	this_thread::sleep_for(chrono::milliseconds(3000));

	if ((rand() % 100) < 50) { // human goes first
		cout << endl << "You go first!" << endl;
		first = 'H';
	}
	else {
		cout << endl << bot->getName() << " goes first!" << endl;
		first = 'B';

	}
	system("pause");


	do {

		result = playIntSet(first); // play set (best of 5 games)

		system("cls");
		cout << endl << result << " won the set!" << endl << endl;
		system("pause");

		// increment the wins variable of the winner
		if (result == humName) humWinSet++;
		else if (result == bot->getName()) botWinSet++;
		else cout << "Err"; // debug purposes

	} while (humWinSet != 7 && botWinSet != 7);

	if (humWinSet > botWinSet) setWinner(humName);
	else if (botWinSet > humWinSet) setWinner(bot->getName());
	else cout << "Err"; // debug purposes


	system("cls");

	cout << "The World Championship Final is over!" << endl << endl;

	cout << getWinner() << " won the World Championship!" << endl << endl;

	cout << "Results:" << endl << endl;
	cout << "  " << humName << " : " << bot->getName() << endl; // : Joe
	cout << "    " << humWinSet << setw(humName.length() + 1) << ":  " << botWinSet << endl << endl;

	system("pause");
}

string Interactive::playIntSet(char& fst) {

	int humWinGame = 0; // to store human's wins
	int botWinGame = 0; // to store bot's wins

	string result = ""; // to store the result

	do {
		result = playIntGame(fst); // play game

		system("cls");
		cout << endl << result << " won the game!" << endl << endl;
		system("pause");

		// increment the wins variable of the winner
		if (result == humName) humWinGame++;
		else if (result == bot->getName()) botWinGame++;
		else cout << "Err"; // debug purposes

		// Like in tennis, after each game, players alternate in throwing first
		if (fst == 'H') fst = 'B';
		else if (fst == 'B') fst = 'H';
		else cout << "Err"; // debug purposes

	} while (humWinGame != 3 && botWinGame != 3);

	// return the winner name
	if (humWinGame > botWinGame) return humName;
	else if (botWinGame > humWinGame) return bot->getName();
	else {
		cout << "Err"; // debug purposes
		return "";
	}

}

string Interactive::playIntGame(char fst) {

	setWinner(""); // reset winner to play another game

	// reset both players' score
	humScore = game;
	bot->setScore(game);

	do {
		if (fst == 'H') {
			humanPlay();
			botPlay();
		}
		else if (fst == 'B') {
			botPlay();
			humanPlay();
		}
		else cout << "Err"; // debug purposes


	//keep playing while neither of the scores is 0, i.e. it will stop when one of the player's score is 0 and that player wins the game
	} while (humScore != 0 && bot->getScore() != 0);

	return getWinner();
}

void Interactive::humanPlay() {
	if (getWinner() != "") return; // If there's already a winner, we don't want to continue playing.

	// Human turn
	system("cls");

	cout << endl << "Your Turn!" << endl;
	cout << "Score: " << humScore << endl << endl;

	// use human score to find best strategy to be shown as hint
	if (hints) vector<string> hintDarts = parseStrategy(searchStrategy(humScore));

	int roundScore = 0; // this round score

	// the next 4 vars store info about the darts thrown in this round and if they were successful.
	//   To be used by func printRoundTable() between each dart
	string firstDart = "";
	bool hitFirst = false;
	string secondDart = "";
	bool hitSecond = false;
	string thirdDart = "";
	bool hitThird = false;


	for (unsigned int i = 0; i < 3; i++) { // throw 3 darts

		string dart = ""; // dart chosen by human
		bool hit = false; // true if throw was successful
		int dartScore = 0; // to store score of each dart thrown

		// print fancy table (empty because it's the first dart)
		if (i == 0) printRoundTable(firstDart, hitFirst, secondDart, hitSecond, thirdDart, hitThird);

		cout << endl << "Where do you want to throw your dart? (Eg: \"T20\", \"D6\", \"S2\", \"B\")" << endl;
		cout << "Score: " << humScore - roundScore << endl;
		if (hints) showHint(roundScore); // if human wanted hints, show hint
		cout << endl;

		do {
			cout << "Option> ";
			cin >> dart;
		} while (!validDartChoice(dart)); // while input is not a valid throw choice, keep asking for input


		if (dart.length() == 1) { // if the the length of the user's choice is 1, it must be "B" => throwBull()
			dartScore = throwBull();

			if (dartScore != 50) cout << endl << "You missed it..." << endl; // missed
			else { // target hit
				hit = true;
				cout << endl << "Nice throw!" << endl;
			}
		}
		else { // convert string into throw, eg "T20" => throwTreble(20)
			int number = 0;

			if (dart.length() == 2) number = stoi(dart.substr(1, 1)); // eg: "D6" => throwDouble(6)
			else /* (dart.length() == 3) */ number = stoi(dart.substr(1, 2)); // eg: "D16" => throwDouble(16)

			switch (dart[0]) {
			case 'S': // it's single		
				dartScore = throwSingle(number);

				if (dartScore != number) cout << endl << "You missed it..." << endl; // missed
				else {
					hit = true; // target hit
					cout << endl << "Nice throw!" << endl;
				}
				break;

			case 'D': // it's double
				dartScore = throwDouble(number);

				if (dartScore != 2 * number) cout << endl << "You missed it..." << endl; // missed
				else {
					hit = true;
					cout << endl << "Nice throw!" << endl;
				}
				break;

			case 'T': // it's treble
				dartScore = throwTreble(number);

				if (dartScore != 3 * number) cout << endl << "You missed it..." << endl; // missed
				else {
					hit = true;
					cout << endl << "Nice throw!" << endl;
				}
				break;

			default:
				cout << "Err"; // for debug purposes
				break;
			}
		}
		cout << endl;
		system("pause");

		roundScore += dartScore; // update round score with this dart's score

		// depending on how many darts were thrown, show fancy table with stats about darts thrown
		if (i == 0) {
			firstDart = dart;
			hitFirst = hit;
			printRoundTable(firstDart, hitFirst, secondDart, hitSecond, thirdDart, hitThird);
		}
		else if (i == 1) {
			secondDart = dart;
			hitSecond = hit;
			printRoundTable(firstDart, hitFirst, secondDart, hitSecond, thirdDart, hitThird);
		}
		else { // i==2 (3rd Dart)
			thirdDart = dart;
			hitThird = hit;
			printRoundTable(firstDart, hitFirst, secondDart, hitSecond, thirdDart, hitThird);
		}


		if (humScore - roundScore == 0) {

			if (dart[0] == 'S' || dart[0] == 'T') { // check what was the last 
				roundScore = 0; // if player is finishing with a treble or a single,
								//  the score is invalid and this round's score is discarded
				break;
			}
			else { // score is valid, human wins
				setWinner(humName);
				break;
			}
		}
		else if (humScore - roundScore < 2) {
			roundScore = 0;
			break; // round is invalid
		}
	}

	humScore -= roundScore; // update human's score 

	cout << endl << "You scored " << roundScore << " in this round." << endl;
	cout << "Now your score is " << humScore << "." << endl << endl;

	system("pause");
}

void Interactive::botPlay() {
	if (getWinner() != "") return; // If there's already a winner, we don't want to continue playing.

	// Bot turn

	system("cls");

	int roundScore = 0; // this round score

	cout << endl << bot->getName() << "'s Turn!" << endl;
	cout << "Score: " << bot->getScore() << endl;

	cout << endl << "Waiting for him to finish his turn";

	// wait some time (between 4 and 8 seconds) for the bot to play 
	int waitBot = rand() % 5 + 4;
	for (int i = 0; i < waitBot; i++) {
		this_thread::sleep_for(chrono::milliseconds(1000));
		cout << ".";
	}
	cout << endl;

	roundScore = playStrategy(bot); // play 1 round for bot player with Enhanced Strategy

	bot->setScore(bot->getScore() - roundScore); // update bot's score after playing round

	cout << endl << bot->getName() << " scored " << roundScore << " in this round." << endl;
	cout << "Now his score is " << bot->getScore() << "." << endl << endl;

	system("pause");

	if (bot->getScore() == 0) { // if the current player won the game with this round, set their name as the winner
		setWinner(bot->getName());
	}

}

void Interactive::printRoundTable(string firstDart, bool hitFirst, string secondDart, bool hitSecond, string thirdDart, bool hitThird) {
	// fancy table to be printed between darts to show stats of the human's round


	system("cls");

	if (firstDart == "") {

		cout << "+----------+----------+----------+" << endl;
		cout << "|          |          |          |" << endl;
		cout << "| 1st Dart | 2nd Dart | 3rd Dart |" << endl;
		cout << "|   ----   |   ----   |   ----   |" << endl;
		cout << "|    --    |    --    |    --    |" << endl;
		cout << "|          |          |          |" << endl;
		cout << "+----------+----------+----------+" << endl;
	}
	else if (secondDart == "") {

		cout << "+----------+----------+----------+" << endl;
		cout << "|          |          |          |" << endl;
		cout << "| 1st Dart | 2nd Dart | 3rd Dart |" << endl;
		cout << "|   " << setw(7) << left << firstDart << "|   ----   |   ----   |" << endl;

		cout << "|    "; if (hitFirst) cout << "V"; else cout << "X";

		cout << "     |    --    |    --    | " << endl;
		cout << "|          |          |          |" << endl;
		cout << "+----------+----------+----------+" << endl;

		system("pause");
	}

	else if (thirdDart == "") {

		cout << "+----------+----------+----------+" << endl;
		cout << "|          |          |          |" << endl;
		cout << "| 1st Dart | 2nd Dart | 3rd Dart |" << endl;
		cout << "|   " << setw(7) << left << firstDart << "|   " << setw(7) << left << secondDart << "|   ----   |" << endl;

		cout << "|    "; if (hitFirst) cout << "V"; else cout << "X"; cout << "     ";
		cout << "|    "; if (hitSecond) cout << "V"; else cout << "X"; cout << "     ";

		cout << "|    --    | " << endl;
		cout << "|          |          |          |" << endl;
		cout << "+----------+----------+----------+" << endl;

		system("pause");
	}
	else {
		cout << "+----------+----------+----------+" << endl;
		cout << "|          |          |          |" << endl;
		cout << "| 1st Dart | 2nd Dart | 3rd Dart |" << endl;
		cout << "|   " << setw(7) << left << firstDart << "|   " << setw(7) << left << secondDart << "|   " << setw(7) << left << thirdDart << "|" << endl;

		cout << "|    "; if (hitFirst) cout << "V"; else cout << "X"; cout << "     ";
		cout << "|    "; if (hitSecond) cout << "V"; else cout << "X"; cout << "     ";
		cout << "|    "; if (hitThird) cout << "V"; else cout << "X"; cout << "     |" << endl;

		cout << "|          |          |          |" << endl;
		cout << "+----------+----------+----------+" << endl;

		cout << "All darts thrown!" << endl << endl;
		system("pause");
	}
}