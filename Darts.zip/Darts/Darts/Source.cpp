﻿#include "Game.h"
#include <iostream>
#include <time.h>

using namespace std;

void printBanner() { // prints banner
	system("cls");

	cout << R"(
                                                                                   ,-'"""`-,    ,-----.
                                                                                 ,' \ _|_ / `.  | 501 |
     _____          _____ _______ _____      _____          __  __ ______       /`.,'\ | /`.,'\ `-----'  |
    |  __ \   /\   |  __ \__   __/ ____|    / ____|   /\   |  \/  |  ____|     (  /`. \|/ ,'\  )      |  H
    | |  | | /  \  | |__) | | | | (___     | |  __   /  \  | \  / | |__        |--|--;=@=:--|--|   |  H  U
    | |  | |/ /\ \ |  _  /  | |  \___ \    | | |_ | / /\ \ | |\/| |  __|       (  \,' /|\ `./  )   H  U  |
    | |__| / ____ \| | \ \  | |  ____) |   | |__| |/ ____ \| |  | | |____       \,'`./ | \,'`./    U  | (|)
    |_____/_/    \_\_|  \_\ |_| |_____/     \_____/_/    \_\_|  |_|______|       `. / """ \ ,'     | (|)
                                                                                   '-._|_,-`      (|)
)";
	cout << "                                                            by Vasco Pinto" << endl << endl << endl;
}

int gameSelector() { // asks which game is to be played
	int gameMode = 0; // game to be played (single, multiple, World Championships or interactive)

	cout << "Game Mode?" << endl << endl;
	cout << "  1: Single 501 Game (Fixed Success Rate - Joe: 71% // Sid: 73%)" << endl;
	cout << "  2: Multiple 501 Games" << endl;
	cout << "  3: World Championships" << endl;
	cout << "  4: Interactive 501 Game" << endl << endl;
	do
	{
		cout << "Option> ";
		cin >> gameMode;

		// prevents bad input to mess with cin
		if (cin.fail()) {
			cin.clear();
			cin.ignore(numeric_limits<streamsize>::max(), '\n');
		}

	} while (gameMode < 1 || gameMode > 4);

	return gameMode;
}

int main() {

	srand((unsigned int)time(NULL)); // rand() seed

	bool playLoop = false; // true if user wants to keep playing

	do {

		// Player objects
		Player joe("Joe", 71);
		Player sid("Sid", 73);

		// Game object
		Game game(&joe, &sid);

		printBanner(); // print banner

		// game to be played (single, multiple, World Championships or interactive)
		int gameMode = gameSelector();

		if (gameMode == 1) game.playSingle(); // play single 501 game
		else if (gameMode == 2) game.playMulti(); // play multiple 501 games
		else if (gameMode == 3) game.playFinal(); // play World Championships
		else game.playInteractive(); // play interactive 501 game

		game.printResults(gameMode); // print game results depending on the game mode

		int keepPlaying = 0; // to store user's choice to keep playing

		cout << endl << endl << "Keep playing?" << endl;
		cout << "  1: Yes" << endl;
		cout << "  2: No" << endl << endl;

		do {
			cout << "Option> ";
			cin >> keepPlaying;

			// prevents bad input to mess with cin
			if (cin.fail()) {
				cin.clear();
				cin.ignore(numeric_limits<streamsize>::max(), '\n');
			}
		} while (keepPlaying != 1 && keepPlaying != 2);

		if (keepPlaying == 1) playLoop = true;
		else playLoop = false;

	} while (playLoop);

	return 0;
}